<template>
	<view class="container">
			发布信息
	</view>
</template>

<script>
	export default {
		components: {
		
		},
		data() {
			return {
				
			}
		},
		watch:{
			
		}
	}
</script>

<style>
	
</style>
